from __future__ import annotations

from typing import Any

from hypothesis import given
from hypothesis import strategies as st

from helixscore.backend.utils.cleaner import deduplicate_leads, normalize_email


@given(st.text(min_size=0, max_size=64))
def test_normalize_email_never_crashes(raw: str) -> None:
    normalized = normalize_email(raw)
    assert isinstance(normalized, str)


@given(st.lists(st.text(min_size=0, max_size=64), min_size=1, max_size=10))
def test_deduplicate_handles_random_emails(emails: list[str]) -> None:
    leads: list[dict[str, Any]] = [
        {"email": email, "meta": {"source": "hypothesis"}} for email in emails
    ]
    unique = deduplicate_leads(leads)
    seen: set[str] = set()
    for lead in unique:
        email = str(lead.get("email", ""))
        assert email not in seen
        seen.add(email)
