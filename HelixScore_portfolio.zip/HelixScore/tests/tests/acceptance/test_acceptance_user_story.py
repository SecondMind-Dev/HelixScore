from __future__ import annotations

from typing import Any, cast

from requests import Response

from helixscore.backend.scoring import generate_scores


def test_sales_manager_can_identify_top_leads(client, sample_leads):
    response = cast(Response, client.post("/score-leads", json={"leads": sample_leads}))
    assert response.status_code == 200
    payload = cast(dict[str, Any], response.json())
    leads = payload["leads"]

    assert len(leads) == len(sample_leads)
    ordered = sorted(leads, key=lambda item: item["score"], reverse=True)
    assert leads[0]["score"] == ordered[0]["score"]

    winners = generate_scores(sample_leads)
    assert winners[0]["score"] >= winners[-1]["score"]
