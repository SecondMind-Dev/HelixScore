from __future__ import annotations

from helix.tests.helpers import run_frontend_command


def test_react_snapshots() -> None:
    result = run_frontend_command(["npm", "run", "test:unit"])
    assert "Test Files" in result.stdout
