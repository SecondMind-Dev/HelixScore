from __future__ import annotations

import os
import subprocess
import time
from collections.abc import Generator

import pytest

from helix.tests.helpers import FRONTEND_DIR, ensure_frontend_deps


@pytest.fixture(scope="session")
def preview_server() -> Generator[subprocess.Popen[str], None, None]:
    ensure_frontend_deps()
    subprocess.run(["npm", "run", "build"], cwd=FRONTEND_DIR, check=True)
    env = os.environ.copy()
    env.setdefault("VITE_API_URL", "http://localhost:8000")
    server = subprocess.Popen(
        ["npm", "run", "preview", "--", "--host", "127.0.0.1", "--port", "4173"],
        cwd=FRONTEND_DIR,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    assert server.stdout is not None
    ready = False
    for _ in range(30):
        line = server.stdout.readline()
        if "Local" in line or "Network" in line:
            ready = True
            break
        time.sleep(1)
    if not ready:
        server.terminate()
        raise RuntimeError("Preview server failed to start")
    try:
        yield server
    finally:
        server.terminate()
        server.wait(timeout=10)


def test_dashboard_playwright(preview_server: subprocess.Popen[str]) -> None:
    env = os.environ.copy()
    env.setdefault("VITE_API_URL", "http://localhost:8000")
    result = subprocess.run(
        ["npx", "playwright", "test"],
        cwd=FRONTEND_DIR,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise AssertionError(result.stdout + "\n" + result.stderr)
