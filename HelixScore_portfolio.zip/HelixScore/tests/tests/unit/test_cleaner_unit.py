from __future__ import annotations

from typing import Any, cast

from helixscore.backend.utils.cleaner import deduplicate_leads, normalize_email


def test_normalize_email_lowercases_and_strips() -> None:
    assert normalize_email("  Foo@Example.COM  ") == "foo@example.com"


def test_deduplicate_leads_removes_duplicates() -> None:
    leads: list[dict[str, Any]] = [
        {"email": "USER@example.com", "name": "User"},
        {"email": "user@example.com", "name": "Duplicate"},
        {"email": "other@example.com", "name": "Other"},
    ]
    unique = deduplicate_leads(cast(list[dict[str, Any]], leads))
    assert len(unique) == 2
    assert any(lead["email"] == "other@example.com" for lead in unique)
