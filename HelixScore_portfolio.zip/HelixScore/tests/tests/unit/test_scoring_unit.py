from __future__ import annotations

from helixscore.backend.scoring import (
    Lead,
    RuleWeights,
    _recency_bonus,
    generate_scores,
)


def test_generate_scores_applies_rule_weights(
    sample_leads: list[dict[str, object]]
) -> None:
    leads = [Lead.model_validate(item) for item in sample_leads]
    weights = RuleWeights(base=30.0, demo_bonus=50.0)
    scored = generate_scores(leads, weights=weights)

    assert all("score" in lead for lead in scored)
    assert max(lead["score"] for lead in scored) <= weights.max_score


def test_recency_bonus_decay() -> None:
    today_bonus = _recency_bonus("2025-10-03")
    old_bonus = _recency_bonus("2024-01-01")
    assert today_bonus >= old_bonus
    assert 0.0 <= today_bonus <= 28.0
