from __future__ import annotations

from typing import Any, cast
from unittest.mock import patch

from requests import Response

from helixscore.backend.scoring import Lead


@patch("helixscore.backend.connectors.aggregator.fetch_live_leads")
def test_leads_endpoint_returns_scores(mock_fetch, client, sample_leads):
    mock_fetch.return_value = [Lead.model_validate(item) for item in sample_leads]
    response = cast(Response, client.get("/leads"))
    payload = cast(dict[str, Any], response.json())
    assert "leads" in payload
    assert all("score" in lead for lead in payload["leads"])


@patch("helixscore.backend.main.post_to_slack")
@patch("helixscore.backend.main.post_to_teams")
@patch("helixscore.backend.connectors.aggregator.fetch_live_leads")
def test_broadcast_uses_webhooks(
    mock_fetch,
    mock_teams,
    mock_slack,
    client,
    sample_leads,
    monkeypatch,
):
    mock_fetch.return_value = [Lead.model_validate(item) for item in sample_leads]
    monkeypatch.setenv("SLACK_WEBHOOK_URL", "https://slack.example")
    monkeypatch.setenv("TEAMS_WEBHOOK_URL", "https://teams.example")
    response = cast(Response, client.post("/broadcast", json={}))
    assert response.status_code == 200
    mock_slack.assert_called_once()
    mock_teams.assert_called_once()
