from __future__ import annotations

import time

from _pytest.monkeypatch import MonkeyPatch

from helixscore.backend.scheduler import start_scheduler, stop_scheduler


def test_scheduler_can_start_and_stop(monkeypatch: MonkeyPatch):
    monkeypatch.setenv("HELIX_SCHEDULER_INTERVAL_MINUTES", "1")
    start_scheduler()
    time.sleep(0.1)
    stop_scheduler()
