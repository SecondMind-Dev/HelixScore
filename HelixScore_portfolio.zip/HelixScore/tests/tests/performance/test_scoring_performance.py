from __future__ import annotations

import random
import time

from helixscore.backend.scoring import Lead, generate_scores


def test_generate_scores_performance(sample_leads):
    amplified = sample_leads * 200  # ~1400 leads
    random.shuffle(amplified)
    leads = [Lead.model_validate(item) for item in amplified]

    start = time.perf_counter()
    scored = generate_scores(leads)
    duration = time.perf_counter() - start

    assert len(scored) == len(leads)
    assert duration < 1.5, f"Scoring took too long: {duration:.2f}s"
