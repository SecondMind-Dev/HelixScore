from __future__ import annotations

import os
from collections.abc import Generator

import pytest
from fastapi.testclient import TestClient

from helixscore.backend.main import app
from helixscore.backend.scoring import load_leads_from_file


@pytest.fixture(scope="session", autouse=True)
def _set_default_env() -> None:
    os.environ.setdefault("HELIX_AI_BOOST", "false")
    os.environ.setdefault("HELIX_ENABLE_SCHEDULER", "false")


@pytest.fixture()
def client() -> Generator[TestClient, None, None]:
    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture()
def sample_leads() -> list[dict[str, object]]:
    return [lead.model_dump() for lead in load_leads_from_file()]
