from __future__ import annotations

from typing import Any, cast

from requests import Response

from helixscore.backend.connectors.aggregator import fetch_live_leads
from helixscore.backend.scoring import generate_scores


def test_end_to_end_scoring_flow(client):
    leads = fetch_live_leads()
    assert leads, "Expected fallback data when APIs unavailable"

    response = cast(
        Response,
        client.post(
            "/score-leads", json={"leads": [lead.model_dump() for lead in leads]}
        ),
    )
    assert response.status_code == 200
    payload = cast(dict[str, Any], response.json())
    assert len(payload["leads"]) == len(leads)

    winners = generate_scores(leads)
    assert winners
