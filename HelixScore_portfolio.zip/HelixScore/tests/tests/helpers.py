from __future__ import annotations

import os
import subprocess
from pathlib import Path

FRONTEND_DIR = Path(__file__).resolve().parents[2] / "helixscore" / "frontend"


def ensure_frontend_deps() -> None:
    node_modules = FRONTEND_DIR / "node_modules"
    if not node_modules.exists():
        subprocess.run(["npm", "install"], cwd=FRONTEND_DIR, check=True)


def run_frontend_command(
    command: list[str],
    *,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess:
    ensure_frontend_deps()
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    return subprocess.run(
        command,
        cwd=FRONTEND_DIR,
        env=merged_env,
        check=True,
        capture_output=True,
        text=True,
    )
