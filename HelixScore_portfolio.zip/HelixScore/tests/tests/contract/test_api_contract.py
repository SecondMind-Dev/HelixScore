from __future__ import annotations

from typing import Any, cast

from jsonschema import Draft7Validator
from requests import Response

SCHEMA = {
    "type": "object",
    "required": ["leads"],
    "properties": {
        "leads": {
            "type": "array",
            "items": {
                "type": "object",
                "required": [
                    "name",
                    "company",
                    "email",
                    "last_activity",
                    "source",
                    "score",
                ],
                "properties": {
                    "name": {"type": "string"},
                    "company": {"type": "string"},
                    "email": {"type": "string"},
                    "last_activity": {"type": "string"},
                    "source": {"type": "string"},
                    "score": {"type": "number"},
                },
            },
        },
    },
}


def test_leads_schema(client):
    response = cast(Response, client.get("/leads"))
    payload = cast(dict[str, Any], response.json())
    Draft7Validator(SCHEMA).validate(payload)
