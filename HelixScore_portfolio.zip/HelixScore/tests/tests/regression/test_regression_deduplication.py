from __future__ import annotations

from typing import Any

from helixscore.backend.connectors.aggregator import leads_as_dicts
from helixscore.backend.scoring import Lead
from helixscore.backend.utils.cleaner import deduplicate_leads


def test_lead_deduplication_regression(sample_leads):
    base_email = str(sample_leads[0]["email"])
    duplicate: dict[str, Any] = sample_leads[0] | {"email": base_email.upper()}
    duplicated = sample_leads + [duplicate]
    unique = deduplicate_leads(duplicated)
    emails = [lead["email"] for lead in unique]
    assert len(unique) == len(sample_leads)
    assert sample_leads[0]["email"] in emails


def test_leads_as_dicts_roundtrip(sample_leads):
    models = [Lead.model_validate(item) for item in sample_leads]
    rounded = leads_as_dicts(models)
    assert rounded == [lead.model_dump() for lead in models]
