"""Generate portfolio artifacts for HelixScore."""

from __future__ import annotations

import logging
from collections.abc import Sequence
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import pandas as pd

from helixscore.backend.scoring import generate_scores, load_leads_from_file
from helixscore.backend.utils.cleaner import deduplicate_leads

matplotlib.use("Agg")

LOGGER = logging.getLogger("helixscore.assets")
ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS_DIR = ROOT / "artifacts"
ARTIFACTS_DIR.mkdir(exist_ok=True)


def dashboard_snapshot(leads: list[dict[str, object]]) -> Path:
    df = pd.DataFrame(leads)
    df = df[["name", "company", "email", "source", "last_activity", "score"]]

    fig, ax = plt.subplots(figsize=(12, 4))
    ax.axis("off")
    ax.set_title("HelixScore Dashboard Snapshot", fontweight="bold", fontsize=14)

    table_values = df.astype(str).values.tolist()
    column_labels = [str(column) for column in df.columns]
    table = ax.table(
        cellText=table_values,
        colLabels=column_labels,
        loc="center",
        cellLoc="center",
    )
    table.scale(1, 1.6)
    for (row, _col), cell in table.get_celld().items():
        if row == 0:
            cell.set_text_props(weight="bold", color="white")
            cell.set_facecolor("#111827")
        else:
            score = float(df.iloc[row - 1]["score"])
            if score >= 85:
                cell.set_facecolor("#ef4444")
            elif score >= 70:
                cell.set_facecolor("#f97316")
            elif score >= 55:
                cell.set_facecolor("#facc15")
            else:
                cell.set_facecolor("#10b981")
            cell.set_text_props(color="#111827")
    fig.patch.set_facecolor("#0f172a")

    output = ARTIFACTS_DIR / "dashboard_snapshot.png"
    fig.savefig(output, bbox_inches="tight", dpi=180)
    plt.close(fig)
    return output


def slack_snapshot(leads: Sequence[dict[str, object]]) -> Path:
    top_lines = [f"• {lead['name']} — {lead['score']} pts" for lead in leads[:5]]
    headline = "HelixScore Hot Leads"
    message = headline if not top_lines else f"{headline}\n" + "\n".join(top_lines)

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.axis("off")
    ax.set_facecolor("#1f2937")
    fig.patch.set_facecolor("#111827")
    ax.text(
        0.02,
        0.95,
        "# sales-war-room",
        fontsize=10,
        color="#9ca3af",
        verticalalignment="top",
    )
    ax.text(
        0.02,
        0.8,
        "HelixScore Bot",
        fontsize=12,
        color="#f3f4f6",
        fontweight="bold",
        verticalalignment="top",
    )
    ax.text(
        0.02,
        0.65,
        message,
        fontsize=11,
        color="#f3f4f6",
        verticalalignment="top",
    )

    output = ARTIFACTS_DIR / "slack_hot_leads.png"
    fig.savefig(output, bbox_inches="tight", dpi=180)
    plt.close(fig)
    return output


def console_snapshot(leads: Sequence[dict[str, object]]) -> Path:
    summary_lines = [
        "HelixScore :: Score Run",
        "=======================",
    ]
    summary_lines.extend(
        f"{lead['name']:<18} | {lead['company']:<20} | {lead['score']:>5}"
        for lead in leads
    )

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.axis("off")
    fig.patch.set_facecolor("#111827")
    ax.set_facecolor("#111827")
    ax.text(
        0.01,
        0.9,
        "\n".join(summary_lines),
        fontsize=11,
        color="#f3f4f6",
        family="monospace",
        verticalalignment="top",
    )

    output = ARTIFACTS_DIR / "console_output.png"
    fig.savefig(output, bbox_inches="tight", dpi=180)
    plt.close(fig)
    return output


def main() -> None:
    leads = [lead.model_dump() for lead in load_leads_from_file()]
    leads = deduplicate_leads(leads)
    scored = generate_scores(leads)
    scored.sort(key=lambda item: item.get("score", 0), reverse=True)

    outputs = [
        dashboard_snapshot(scored),
        slack_snapshot(scored),
        console_snapshot(scored),
    ]

    for path in outputs:
        LOGGER.info("Generated %s", path.relative_to(ROOT))


if __name__ == "__main__":
    main()
