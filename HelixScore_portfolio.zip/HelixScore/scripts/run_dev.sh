#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
API_PORT=${API_PORT:-8000}
WEB_PORT=${WEB_PORT:-5173}
PYTHON_BIN="${ROOT_DIR}/.venv/bin/python"

if [[ ! -x "${PYTHON_BIN}" ]]; then
  PYTHON_BIN=$(command -v python3)
fi

if [[ ! -x "${PYTHON_BIN}" ]]; then
  echo "[helixscore] Unable to locate python interpreter" >&2
  exit 1
fi

kill_port() {
  local port=$1
  if command -v lsof >/dev/null; then
    local pids
    pids=$(lsof -t -i tcp:${port} || true)
    if [[ -n "${pids}" ]]; then
      echo "[helixscore] freeing port ${port} (PIDs: ${pids})"
      kill ${pids} 2>/dev/null || true
    fi
  fi
}

kill_port "${API_PORT}"
kill_port "${WEB_PORT}"

pushd "${ROOT_DIR}/helixscore/frontend" >/dev/null
if [[ ! -d node_modules ]]; then
  echo "[helixscore] Installing frontend dependencies..."
  npm install >/dev/null
fi
popd >/dev/null

cleanup() {
  trap - INT TERM EXIT
  if [[ -n "${BACK_PID:-}" ]]; then
    kill "${BACK_PID}" 2>/dev/null || true
  fi
  if [[ -n "${WEB_PID:-}" ]]; then
    kill "${WEB_PID}" 2>/dev/null || true
  fi
}
trap cleanup INT TERM EXIT

${PYTHON_BIN} -m uvicorn helixscore.backend.main:app --reload --host 0.0.0.0 --port "${API_PORT}" &
BACK_PID=$!

pushd "${ROOT_DIR}/helixscore/frontend" >/dev/null
npm run dev -- --host 0.0.0.0 --port "${WEB_PORT}" &
WEB_PID=$!
popd >/dev/null

echo
echo "HelixScore running:"
echo "  • API: http://localhost:${API_PORT} (docs at /docs)"
echo "  • UI : http://localhost:${WEB_PORT}"
echo "Press Ctrl+C to stop both servers."
echo

wait "${BACK_PID}" "${WEB_PID}"
