# HelixScore Demo Narration (≈60 seconds)

1. **Cold open (0-10s)**
   - “Welcome to HelixScore—the cross-CRM lead nerve center. Let me show you how we turn three chaotic pipelines into one unified command hub.”

2. **Scoring API kick (10-25s)**
   - On terminal: run `curl` against `/score-leads`.
   - Narration: “The FastAPI backend pulls data from HubSpot, Salesforce, or Pipedrive—falling back to sample JSON when creds aren’t present. Every lead is normalized, deduped, and scored with our rule matrix plus an optional GPT-powered boost.”

3. **Dashboard tour (25-40s)**
   - Switch to React UI (`npm run dev`).
   - Highlight heat-mapped scores, lead drawer, and CRM badges.
   - Narration: “The dashboard immediately lights up with color-coded priority. Click any lead to see engagement signals—email opens, call connects, deal stage, and more. The trend chart tracks average score by activity date so sales ops can spot momentum at a glance.”

4. **Webhook blast (40-50s)**
   - Trigger `/broadcast` (simulate Slack).
   - Narration: “When it’s time to rally the team, a single endpoint blasts the top five leads to Slack or Microsoft Teams with the exact score and context they need.”

5. **Outro + deploy (50-60s)**
   - Show Render deploy badge / deploy folder.
   - Narration: “Everything ships production-ready: one-click deploy manifests for Render or Fly.io, a scheduler that auto-pings every six hours, and a pytest + Playwright suite guarding the entire flow. HelixScore is portfolio-ready and client-ready.”
