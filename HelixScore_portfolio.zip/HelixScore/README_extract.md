# HelixScore (Standalone Extract)

This document explains how to run HelixScore when the `helixscore/` directory is copied into a fresh repository.

## 1. Requirements
- Python 3.10+
- Node.js 18+
- Optional: Render or Fly.io accounts for deployment

## 2. Install & Run (Local)
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn backend.main:app --reload
```

In a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Visit `http://localhost:5173` for the dashboard.

## 3. Environment Variables
Copy `.env.template` to `.env` and fill in CRM + webhook credentials:
```
HUBSPOT_API_KEY=
SALESFORCE_INSTANCE_URL=
SALESFORCE_ACCESS_TOKEN=
PIPEDRIVE_API_KEY=
SLACK_WEBHOOK_URL=
TEAMS_WEBHOOK_URL=
HELIX_AI_BOOST=false
HELIX_ENABLE_SCHEDULER=false
HELIX_SCHEDULER_INTERVAL_MINUTES=360
VITE_API_URL=http://localhost:8000
```

## 4. Portfolio Assets
```bash
.venv/bin/python -m helixscore.scripts.generate_assets
```
Screenshots are saved to `artifacts/` for use in README or pitch decks.

## 5. Playwright Setup
```bash
cd frontend
npm install
npx playwright install
npx playwright test
```

## 6. Deployment Shortcuts
- **Render:** deploy using `deploy/render.yaml`
- **Fly.io:** `fly launch --copy-config` from `deploy/`

## 7. Test Suite
```bash
.venv/bin/pytest helix/tests
```

## 8. Scheduler
Enable the worker to broadcast hot leads every 6 hours:
```bash
export HELIX_ENABLE_SCHEDULER=true
uvicorn backend.main:app --host 0.0.0.0 --port 8000
```

Enjoy shipping HelixScore on its own.
