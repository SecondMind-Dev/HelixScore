import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './tests/ui',
  timeout: 60 * 1000,
  use: {
    baseURL: 'http://localhost:4173',
    headless: true,
  },
});
