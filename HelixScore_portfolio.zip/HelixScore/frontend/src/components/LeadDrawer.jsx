const SignalItem = ({ label, value }) => (
  <li className="flex items-center justify-between text-sm">
    <span className="text-slate-400">{label}</span>
    <span className="text-slate-100 font-medium">{value}</span>
  </li>
);

function LeadDrawer({ lead }) {
  if (!lead) {
    return (
      <div className="text-slate-400 text-sm">
        Select a lead to inspect CRM history.
      </div>
    );
  }

  const metadata = lead.metadata || {};
  const badgeTone = metadata.deal_stage?.toLowerCase().includes("proposal")
    ? "from-amber-500/30 to-amber-500/10"
    : "from-sky-500/30 to-sky-500/10";

  return (
    <div className="space-y-5">
      <header className="bg-gradient-to-br from-emerald-500/20 to-slate-900/30 rounded-2xl border border-emerald-500/30 p-4 shadow-lg shadow-emerald-500/10">
        <p className="text-xs uppercase tracking-[0.35em] text-emerald-200/80">
          Active Lead
        </p>
        <h2 className="mt-1 text-2xl font-semibold text-slate-50">{lead.name}</h2>
        <p className="text-slate-200/80">{lead.company}</p>
        <div className="mt-3 inline-flex items-center gap-2 rounded-full border border-slate-200/20 bg-slate-900/60 px-3 py-1 text-xs uppercase tracking-widest text-slate-200/70">
          {lead.source}
        </div>
      </header>

      <div className="rounded-2xl border border-slate-700/60 bg-slate-900/60 p-4 space-y-3 shadow-inner shadow-black/20">
        <Row label="Email" value={lead.email} />
        <Row label="Last Activity" value={lead.last_activity} />
        <Row
          label="Score"
          value={`${Math.round(lead.score)} / 100`}
          className="text-emerald-300 font-semibold"
        />
        <div className={`rounded-xl border border-slate-700/60 bg-gradient-to-r ${badgeTone} px-3 py-2 text-xs uppercase tracking-widest text-slate-100/90`}
        >
          Stage: {metadata.deal_stage ?? "Unknown"}
        </div>
      </div>

      <div className="rounded-2xl border border-slate-700/50 bg-slate-900/50 p-4">
        <p className="text-xs uppercase tracking-widest text-slate-400 mb-3">
          Engagement Signals
        </p>
        <ul className="space-y-2 text-sm text-slate-300">
          <SignalItem label="Email opens" value={metadata.email_opens ?? 0} />
          <SignalItem label="Call connects" value={metadata.call_connects ?? 0} />
          <SignalItem label="Demo booked" value={metadata.demo_booked ? "Yes" : "No"} />
          <SignalItem label="Account tier" value={metadata.account_tier ?? "N/A"} />
          <SignalItem
            label="Churn risk"
            value={metadata.churn_risk ? metadata.churn_risk : "Low"}
          />
        </ul>
      </div>
    </div>
  );
}

function Row({ label, value, className = "" }) {
  return (
    <div className="flex justify-between text-sm">
      <span className="text-slate-400">{label}</span>
      <span className={`text-slate-100 ${className}`}>{value}</span>
    </div>
  );
}

export default LeadDrawer;
