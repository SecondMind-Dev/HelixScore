const scoreToColor = (score) => {
  if (score >= 85) return "bg-gradient-to-r from-rose-500/90 to-orange-500/80";
  if (score >= 70) return "bg-gradient-to-r from-orange-400/80 to-amber-400/70";
  if (score >= 55) return "bg-gradient-to-r from-yellow-400/70 to-lime-400/60";
  return "bg-gradient-to-r from-emerald-400/70 to-emerald-500/60";
};

function LeadTable({ leads, onSelect, selectedEmail }) {
  if (!leads.length) {
    return <p className="text-slate-400">No leads scored yet. Trigger a run!</p>;
  }

  return (
    <div className="overflow-x-auto rounded-2xl border border-slate-800/60 bg-slate-950/40 backdrop-blur">
      <table className="w-full border-collapse text-left">
        <thead className="text-slate-200 uppercase text-xs bg-slate-900/80">
          <tr className="tracking-widest">
            <th className="py-2 px-3">Name</th>
            <th className="px-3">Company</th>
            <th className="px-3">Email</th>
            <th className="px-3">Source</th>
            <th className="px-3">Last Activity</th>
            <th className="px-3">Score</th>
          </tr>
        </thead>
        <tbody>
          {leads.map((lead) => {
            const isActive = lead.email === selectedEmail;
            const rowClasses = isActive
              ? "bg-slate-900/80 ring-2 ring-amber-400/60 shadow-lg shadow-amber-500/10"
              : "hover:bg-slate-900/40";
            return (
              <tr
                key={lead.email}
                role="button"
                tabIndex={0}
                onClick={() => onSelect?.(lead)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    onSelect?.(lead);
                  }
                }}
                className={`border-b border-slate-900 cursor-pointer transition-all duration-150 ${rowClasses}`}
              >
                <td className="relative py-3 px-3 font-semibold">
                  <span className="pr-6 inline-flex items-center gap-2">
                    <span>{lead.name}</span>
                    {isActive && (
                      <span className="text-xs text-amber-300 animate-pulse">
                        Viewing
                      </span>
                    )}
                  </span>
                </td>
                <td className="px-3 text-slate-200/90">{lead.company}</td>
                <td className="px-3 text-slate-300">{lead.email}</td>
                <td className="px-3">
                  <span className="px-2 py-1 text-xs rounded-full bg-slate-800/80 uppercase tracking-wide">
                    {lead.source}
                  </span>
                </td>
                <td className="px-3 text-slate-300">{lead.last_activity}</td>
                <td className="px-3">
                  <span
                    className={`inline-flex min-w-[3rem] justify-center px-3 py-1 rounded-full text-slate-900 font-bold shadow-inner ${scoreToColor(
                      lead.score
                    )}`}
                  >
                    {Math.round(lead.score)}
                  </span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export default LeadTable;
