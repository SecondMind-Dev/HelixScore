import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

function ScoreTrendChart({ points }) {
  const hasData = points && points.some((point) => point.count > 0);

  return (
    <div className="bg-slate-900/40 border border-slate-800/70 rounded-lg p-4">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-xl font-semibold">Score Trend</h2>
          <p className="text-slate-400 text-sm">Average lead score by last activity</p>
        </div>
      </div>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={points}>
            <defs>
              <linearGradient id="scoreGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f97316" stopOpacity={0.9} />
                <stop offset="95%" stopColor="#22c55e" stopOpacity={0.2} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" />
            <XAxis dataKey="date" stroke="#94a3b8" tickLine={false} />
            <YAxis
              stroke="#94a3b8"
              tickLine={false}
              domain={[0, 100]}
              tickFormatter={(value) => `${value}`}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#0f172a",
                border: "1px solid #1f2937",
                borderRadius: "0.5rem",
              }}
              labelStyle={{ color: "#e2e8f0" }}
              formatter={(value) => [`${value} pts`, "Avg Score"]}
            />
            <Area
              type="monotone"
              dataKey="avg_score"
              stroke="#f97316"
              strokeWidth={2}
              fill="url(#scoreGradient)"
              isAnimationActive={hasData}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export default ScoreTrendChart;
