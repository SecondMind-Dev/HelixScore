const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

export async function fetchLeads() {
  const response = await fetch(`${BASE_URL}/leads`);
  if (!response.ok) {
    throw new Error(`Failed to fetch leads: ${response.status}`);
  }
  const data = await response.json();
  return data.leads ?? [];
}

export async function fetchScoreTrend() {
  const response = await fetch(`${BASE_URL}/metrics/score-trend`);
  if (!response.ok) {
    throw new Error(`Failed to fetch score trend: ${response.status}`);
  }
  return response.json();
}

export async function triggerScoreRun(payload) {
  const response = await fetch(`${BASE_URL}/score-leads`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!response.ok) {
    throw new Error(`Score run failed: ${response.status}`);
  }
  const data = await response.json();
  return data.leads ?? [];
}
