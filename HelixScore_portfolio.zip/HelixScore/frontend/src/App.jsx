import { useEffect, useMemo, useRef, useState } from "react";
import LeadTable from "./components/LeadTable";
import LeadDrawer from "./components/LeadDrawer";
import ScoreTrendChart from "./components/ScoreTrendChart";
import { fetchLeads, fetchScoreTrend } from "./api";

function App() {
  const [leads, setLeads] = useState([]);
  const [selectedLead, setSelectedLead] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [trendPoints, setTrendPoints] = useState([]);
  const [drawerPulse, setDrawerPulse] = useState(false);
  const drawerRef = useRef(null);

  useEffect(() => {
    setIsLoading(true);
    Promise.all([fetchLeads(), fetchScoreTrend()])
      .then(([leadData, trendData]) => {
        setLeads(leadData);
        setTrendPoints(trendData.points ?? []);
        if (leadData.length) {
          setSelectedLead(leadData[0]);
        }
      })
      .catch((err) => {
        console.error("Failed to load HelixScore data", err);
        setError("Could not load HelixScore data. Ensure the backend is running.");
      })
      .finally(() => setIsLoading(false));
  }, []);

  useEffect(() => {
    if (!selectedLead) return;
    if (typeof window === "undefined") return;
    const drawer = drawerRef.current;
    if (!drawer) return;
    drawer.scrollIntoView({ behavior: "smooth", block: "nearest" });
    setDrawerPulse(true);
    const timer = window.setTimeout(() => setDrawerPulse(false), 650);
    return () => window.clearTimeout(timer);
  }, [selectedLead]);

  const metrics = useMemo(() => {
    if (!leads.length) return null;
    const total = leads.length;
    const avgScore = Math.round(
      leads.reduce((sum, lead) => sum + Number(lead.score ?? 0), 0) / total
    );
    const hot = leads.filter((lead) => Number(lead.score ?? 0) >= 80).length;
    const topLead = [...leads].sort((a, b) => (b.score ?? 0) - (a.score ?? 0))[0];
    const sourceCounts = leads.reduce((acc, lead) => {
      const key = lead.source ?? "Unknown";
      acc[key] = (acc[key] ?? 0) + 1;
      return acc;
    }, {});
    const dominantSource = Object.entries(sourceCounts).sort((a, b) => b[1] - a[1])[0] ?? ["Unknown", 0];
    return { total, avgScore, hot, topLead, dominantSource };
  }, [leads]);

  const handleLeadSelect = (lead) => {
    setSelectedLead(lead);
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-950 via-zinc-950 to-indigo-950 text-slate-50 flex flex-col lg:flex-row">
      <section className="flex-1 p-8 space-y-6">
        <header className="space-y-2">
          <span className="inline-flex items-center rounded-full border border-emerald-400/40 bg-emerald-500/10 px-3 py-1 text-xs uppercase tracking-widest text-emerald-200/80">
            HelixScore Intelligence
          </span>
          <h1 className="text-3xl font-bold">HelixScore Command Hub</h1>
          <p className="text-slate-300">Cross-CRM priority intelligence on autopilot.</p>
        </header>
        {metrics && (
          <div className="grid gap-4 md:grid-cols-3">
            <SummaryCard
              title="Leads scored"
              highlight={`${metrics.total}`}
              subLabel={`Avg score ${metrics.avgScore}`}
              accent="from-emerald-500/20 to-emerald-500/5"
            />
            <SummaryCard
              title="Hot streak"
              highlight={`${metrics.hot}`} 
              subLabel="Score ≥ 80"
              accent="from-amber-500/20 to-amber-500/5"
            />
            <SummaryCard
              title="Top performer"
              highlight={metrics.topLead?.name ?? "—"}
              subLabel={`Score ${Math.round(metrics.topLead?.score ?? 0)} · ${metrics.dominantSource[0]}`}
              accent="from-sky-500/20 to-sky-500/5"
            />
          </div>
        )}
        {isLoading && <p className="text-slate-400 animate-pulse">Scoring leads…</p>}
        {error && (
          <div className="bg-red-500/10 border border-red-500/50 text-red-200 px-4 py-3 rounded">
            {error}
          </div>
        )}
        <ScoreTrendChart points={trendPoints} />
        <LeadTable
          leads={leads}
          selectedEmail={selectedLead?.email}
          onSelect={handleLeadSelect}
        />
      </section>
      <aside
        ref={drawerRef}
        id="lead-drawer"
        className={`lg:w-96 border-t lg:border-t-0 lg:border-l border-slate-800/70 bg-slate-900/50 p-6 transition duration-500 ${
          drawerPulse ? "ring-2 ring-amber-400/40 shadow-lg shadow-amber-500/15" : ""
        }`}
      >
        <LeadDrawer lead={selectedLead} />
      </aside>
    </main>
  );
}

function SummaryCard({ title, highlight, subLabel, accent }) {
  return (
    <div
      className={`rounded-xl border border-slate-700/60 bg-gradient-to-br ${accent} p-4 shadow-lg shadow-black/30 backdrop-blur`}
    >
      <p className="text-xs uppercase tracking-widest text-slate-300/80">{title}</p>
      <p className="mt-2 text-3xl font-semibold text-slate-50">{highlight}</p>
      <p className="mt-1 text-sm text-slate-300/80">{subLabel}</p>
    </div>
  );
}

export default App;
