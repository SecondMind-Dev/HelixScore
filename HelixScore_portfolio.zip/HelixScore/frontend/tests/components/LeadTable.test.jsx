import { render, screen } from '@testing-library/react';
import LeadTable from '../../src/components/LeadTable.jsx';

const leads = [
  {
    name: 'Jordan Reese',
    company: 'NovaGrid',
    email: 'jordan@nova.com',
    source: 'Salesforce',
    last_activity: '2025-09-30',
    score: 88,
  },
];

it('renders lead rows and matches snapshot', () => {
  const { container } = render(
    <LeadTable leads={leads} selectedEmail={leads[0].email} onSelect={() => {}} />
  );
  expect(screen.getByText('Jordan Reese')).toBeInTheDocument();
  expect(container).toMatchSnapshot();
});
