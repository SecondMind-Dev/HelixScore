import { render } from '@testing-library/react';
import ScoreTrendChart from '../../src/components/ScoreTrendChart.jsx';

const points = [
  { date: '2025-09-27', avg_score: 50, count: 2 },
  { date: '2025-09-28', avg_score: 75, count: 5 },
  { date: '2025-09-29', avg_score: 80, count: 3 },
];

it('renders score trend chart snapshot', () => {
  const { container } = render(<ScoreTrendChart points={points} />);
  expect(container).toMatchSnapshot();
});
