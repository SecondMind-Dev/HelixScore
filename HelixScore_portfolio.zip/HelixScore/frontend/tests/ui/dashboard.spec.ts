import { test, expect } from '@playwright/test';

const API_STUB = {
  leads: [
    {
      name: 'Jordan Reese',
      company: 'NovaGrid Analytics',
      email: 'jordan.reese@novagrid.co',
      last_activity: '2025-09-30',
      source: 'Salesforce',
      score: 88,
      metadata: { email_opens: 7, call_connects: 3 },
    },
  ],
};

const TREND_STUB = {
  points: [
    { date: '2025-09-27', avg_score: 52, count: 3 },
    { date: '2025-09-28', avg_score: 73, count: 5 },
    { date: '2025-09-29', avg_score: 81, count: 4 },
  ],
};

test('dashboard renders leads and chart', async ({ page }) => {
  await page.route('**/leads', (route) => route.fulfill({ json: API_STUB }));
  await page.route('**/metrics/score-trend', (route) => route.fulfill({ json: TREND_STUB }));

  await page.goto('http://localhost:4173');

  await expect(page.getByText('HelixScore Command Hub')).toBeVisible();
  await expect(page.getByRole('cell', { name: 'Jordan Reese' })).toBeVisible();
  await expect(page.getByText('Score Trend')).toBeVisible();
});
