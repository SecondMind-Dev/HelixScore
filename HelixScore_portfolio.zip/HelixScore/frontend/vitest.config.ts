import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    environment: "jsdom",
    setupFiles: ["./vitest.setup.ts"],
    exclude: ["tests/ui/**", "**/node_modules/**"],
    coverage: {
      enabled: true,
      reporter: ["text", "lcov"],
      exclude: ["tests/ui/**", "**/node_modules/**"],
    },
  },
});
