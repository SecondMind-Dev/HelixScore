"""FastAPI application entrypoint for HelixScore."""

from __future__ import annotations

import os
from datetime import datetime, timedelta
from typing import Any

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .connectors.aggregator import fetch_live_leads
from .scheduler import start_scheduler, stop_scheduler
from .scoring import (
    Lead,
    ScoreRequest,
    generate_scores,
    top_leads,
)
from .utils.webhook import post_to_slack, post_to_teams

app = FastAPI(title="HelixScore", version="0.3.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def _startup() -> None:
    if _env_truthy("HELIX_ENABLE_SCHEDULER"):
        start_scheduler()


@app.on_event("shutdown")
async def _shutdown() -> None:
    stop_scheduler()


@app.get("/health")
def health_check() -> dict[str, str]:
    """Return a simple health payload."""
    return {"status": "ok"}


@app.get("/leads")
def fetch_scored_leads() -> dict[str, list[dict[str, Any]]]:
    """Return scored leads from live connectors or fallback data."""

    leads = fetch_live_leads()
    results = generate_scores(leads, use_ai_boost=_env_ai_boost())
    return {"leads": results}


@app.post("/score-leads")
def score_leads(payload: ScoreRequest) -> dict[str, list[dict[str, Any]]]:
    """Trigger the scoring engine for a supplied batch of leads."""

    if payload.leads:
        leads = [Lead.model_validate(item) for item in payload.leads]
    else:
        leads = fetch_live_leads()
    results = generate_scores(leads, use_ai_boost=_resolve_flag(payload.use_ai_boost))
    return {"leads": results}


@app.post("/broadcast")
def broadcast_top_leads(request: ScoreRequest) -> dict[str, Any]:
    """Send the top leads to configured webhook endpoints."""

    slack_url = os.getenv("SLACK_WEBHOOK_URL")
    teams_url = os.getenv("TEAMS_WEBHOOK_URL")
    if not slack_url and not teams_url:
        return {"status": "skipped", "reason": "Missing webhook URLs"}

    if request.leads:
        leads = [Lead.model_validate(item) for item in request.leads]
    else:
        leads = fetch_live_leads()

    winners = top_leads(leads, use_ai_boost=_resolve_flag(request.use_ai_boost))

    if slack_url:
        post_to_slack(slack_url, winners)
    if teams_url:
        post_to_teams(teams_url, winners)

    return {"status": "ok", "count": len(winners)}


@app.get("/metrics/score-trend")
def score_trend() -> dict[str, list[dict[str, Any]]]:
    """Return average score by last-activity date for charting."""

    leads = fetch_live_leads()
    scored = generate_scores(leads, use_ai_boost=_env_ai_boost())

    buckets: dict[str, list[float]] = {}
    for lead in scored:
        bucket = buckets.setdefault(lead["last_activity"], [])
        bucket.append(float(lead["score"]))

    if not buckets:
        today = datetime.utcnow().date()
        buckets = {today.isoformat(): [0.0]}

    points = []
    for day, scores in buckets.items():
        avg = sum(scores) / max(len(scores), 1)
        points.append(
            {
                "date": day,
                "avg_score": round(avg, 2),
                "count": len(scores),
            }
        )

    points.sort(key=lambda item: item["date"])

    normalized = []
    today = datetime.utcnow().date()
    window = [today - timedelta(days=i) for i in range(6, -1, -1)]
    current_index = {p["date"]: p for p in points}
    for day in window:
        iso = day.isoformat()
        if iso in current_index:
            normalized.append(current_index[iso])
        else:
            normalized.append({"date": iso, "avg_score": 0.0, "count": 0})

    return {"points": normalized}


def _env_ai_boost() -> bool:
    return _resolve_flag(None)


def _resolve_flag(flag: bool | None) -> bool:
    if flag is not None:
        return flag
    return _env_truthy("HELIX_AI_BOOST")


def _env_truthy(key: str, default: str = "0") -> bool:
    value = os.getenv(key, default).strip().lower()
    return value in {"1", "true", "yes", "on"}


__all__ = ["app", "Lead"]
