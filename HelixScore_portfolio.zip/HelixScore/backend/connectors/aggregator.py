"""Helpers for aggregating CRM leads."""

from __future__ import annotations

import os
from collections.abc import Iterable
from typing import Any

from ..scoring import Lead, load_leads_from_file
from ..utils.cleaner import deduplicate_leads
from . import hubspot, pipedrive, salesforce


def fetch_live_leads() -> list[Lead]:
    """Collect leads from any configured CRM connectors."""

    collected: list[dict[str, Any]] = []

    hubspot_key = os.getenv("HUBSPOT_API_KEY")
    if hubspot_key:
        collected.extend(hubspot.fetch_leads(hubspot_key))

    pipedrive_key = os.getenv("PIPEDRIVE_API_KEY")
    if pipedrive_key:
        collected.extend(pipedrive.fetch_leads(pipedrive_key))

    salesforce_token = os.getenv("SALESFORCE_ACCESS_TOKEN")
    salesforce_instance = os.getenv("SALESFORCE_INSTANCE_URL")
    if salesforce_token and salesforce_instance:
        collected.extend(salesforce.fetch_leads(salesforce_instance, salesforce_token))

    if not collected:
        fallback = [lead.model_dump() for lead in load_leads_from_file()]
        return [Lead.model_validate(item) for item in fallback]

    cleaned = deduplicate_leads(collected)
    return [Lead.model_validate(item) for item in cleaned]


def leads_as_dicts(leads: Iterable[Lead]) -> list[dict[str, Any]]:
    """Convert Lead models into dictionaries."""

    return [lead.model_dump() for lead in leads]


__all__ = ["fetch_live_leads", "leads_as_dicts"]
