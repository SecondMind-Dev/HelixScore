"""Pipedrive connector implementation."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime
from typing import Any

import requests

API_URL = "https://api.pipedrive.com/v1/deals"


def fetch_leads(api_key: str, *, limit: int = 50) -> list[dict[str, Any]]:
    """Fetch deal data from Pipedrive and map to lead schema."""

    deals = _request_deals(api_key, limit=limit)
    return [_deal_to_lead(deal) for deal in deals]


def _request_deals(api_key: str, *, limit: int) -> list[Mapping[str, Any]]:
    params = {
        "api_token": api_key,
        "status": "open",
        "limit": limit,
        "sort": "update_time DESC",
    }

    try:
        response = requests.get(API_URL, params=params, timeout=10)
        response.raise_for_status()
    except requests.RequestException:
        return []

    payload = response.json()
    data = payload.get("data")
    if isinstance(data, list):
        return [item for item in data if isinstance(item, Mapping)]
    return []


def _deal_to_lead(deal: Mapping[str, Any]) -> dict[str, Any]:
    person = _as_mapping(deal.get("person_id"))
    org = _as_mapping(deal.get("org_id"))
    name = person.get("name") or deal.get("title") or "Pipedrive Lead"
    email = _extract_email(person)
    last_activity = deal.get("update_time") or deal.get("add_time")
    return {
        "name": name,
        "company": org.get("name") or "Unknown",
        "email": email or f"pd-{deal.get('id')}@example.com",
        "last_activity": _to_iso(str(last_activity) if last_activity else None),
        "source": "Pipedrive",
        "metadata": {
            "stage_change_time": deal.get("stage_change_time"),
            "won_time": deal.get("won_time"),
            "lost_time": deal.get("lost_time"),
            "value": deal.get("value"),
        },
    }


def _as_mapping(value: object) -> Mapping[str, Any]:
    if isinstance(value, Mapping):
        return value
    if isinstance(value, dict):
        return value
    return {}


def _extract_email(person: Mapping[str, Any]) -> str | None:
    emails = person.get("email")
    if isinstance(emails, list) and emails:
        candidate = emails[0]
        if isinstance(candidate, dict):
            return candidate.get("value")
        if isinstance(candidate, str):
            return candidate
    return None


def _to_iso(value: str | None) -> str:
    if not value:
        return datetime.utcnow().date().isoformat()
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt.date().isoformat()
    except ValueError:
        return datetime.utcnow().date().isoformat()
