"""Salesforce connector implementation."""

from __future__ import annotations

from datetime import datetime
from typing import Any

import requests

DEFAULT_QUERY = (
    "SELECT Id, Name, Company, Email, Status, LastModifiedDate "
    "FROM Lead ORDER BY LastModifiedDate DESC LIMIT 50"
)


def fetch_leads(
    instance_url: str,
    access_token: str,
    *,
    soql: str | None = None,
) -> list[dict[str, Any]]:
    """Fetch lead records from Salesforce using a SOQL query."""

    query = soql or DEFAULT_QUERY
    url = f"{instance_url.rstrip('/')}/services/data/v60.0/query"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }
    params = {"q": query}

    try:
        response = requests.get(url, headers=headers, params=params, timeout=10)
        response.raise_for_status()
    except requests.RequestException:
        return []

    payload = response.json()
    records = payload.get("records") or []
    leads: list[dict[str, Any]] = []
    for record in records:
        name = record.get("Name") or "Salesforce Lead"
        leads.append(
            {
                "name": name,
                "company": record.get("Company") or "Unknown",
                "email": record.get("Email") or f"sf-{record.get('Id')}@example.com",
                "last_activity": _to_iso(record.get("LastModifiedDate")),
                "source": "Salesforce",
                "metadata": {
                    "status": record.get("Status"),
                    "salesforce_id": record.get("Id"),
                },
            }
        )
    return leads


def _to_iso(value: str | None) -> str:
    if not value:
        return datetime.utcnow().date().isoformat()
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt.date().isoformat()
    except ValueError:
        return datetime.utcnow().date().isoformat()
