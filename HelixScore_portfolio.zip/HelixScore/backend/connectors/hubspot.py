"""HubSpot connector implementation."""

from __future__ import annotations

from datetime import datetime
from typing import Any

import requests

API_URL = "https://api.hubspot.com/crm/v3/objects/contacts"
PROPERTIES = [
    "firstname",
    "lastname",
    "company",
    "email",
    "lastmodifieddate",
    "lifecyclestage",
    "hs_latest_activity_type",
]


def fetch_leads(api_key: str, *, limit: int = 25) -> list[dict[str, Any]]:
    """Fetch lead data from HubSpot using a private app token."""

    headers = {"Authorization": f"Bearer {api_key}"}
    params = {"limit": limit, "properties": ",".join(PROPERTIES)}

    try:
        response = requests.get(API_URL, headers=headers, params=params, timeout=10)
        response.raise_for_status()
    except requests.RequestException:
        return []

    payload = response.json()
    results: list[dict[str, Any]] = []
    for item in payload.get("results", []):
        props = item.get("properties", {})
        firstname = props.get("firstname") or ""
        lastname = props.get("lastname") or ""
        name = (
            (firstname + " " + lastname).strip()
            or props.get("company")
            or "HubSpot Lead"
        )
        last_activity = _to_iso(props.get("lastmodifieddate"))
        results.append(
            {
                "name": name,
                "company": props.get("company") or "Unknown",
                "email": props.get("email") or f"hs-{item.get('id')}@example.com",
                "last_activity": last_activity,
                "source": "HubSpot",
                "metadata": {
                    "lifecycle_stage": props.get("lifecyclestage"),
                    "latest_activity": props.get("hs_latest_activity_type"),
                    "hubspot_id": item.get("id"),
                },
            }
        )
    return results


def _to_iso(value: str | None) -> str:
    if not value:
        return datetime.utcnow().date().isoformat()
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt.date().isoformat()
    except ValueError:
        return datetime.utcnow().date().isoformat()
