"""Data hygiene helpers for HelixScore."""

from __future__ import annotations

from collections.abc import Iterable


def normalize_email(email: str) -> str:
    """Lowercase and trim an email string."""

    return email.strip().lower()


def deduplicate_leads(leads: Iterable[dict[str, object]]) -> list[dict[str, object]]:
    """Remove duplicate lead records by email."""

    seen: set[str] = set()
    unique: list[dict[str, object]] = []
    for lead in leads:
        email = normalize_email(str(lead.get("email", "")))
        if email and email not in seen:
            seen.add(email)
            unique.append(lead)
    return unique
