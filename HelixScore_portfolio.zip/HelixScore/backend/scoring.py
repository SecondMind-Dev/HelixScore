"""Lead scoring utilities for HelixScore."""

from __future__ import annotations

import json
import os
import re
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any

from pydantic import BaseModel

DEFAULT_DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "sample_leads.json"


@dataclass(slots=True)
class RuleWeights:
    """Configuration for rule-based scoring."""

    base: float = 35.0
    max_score: float = 100.0
    source_weights: dict[str, float] = None  # type: ignore[assignment]
    demo_bonus: float = 25.0
    hot_stage_bonus: float = 12.0
    enterprise_bonus: float = 8.0
    churn_penalty: float = 18.0

    def __post_init__(self) -> None:  # noqa: D401
        if self.source_weights is None:
            self.source_weights = {
                "salesforce": 24.0,
                "hubspot": 18.0,
                "pipedrive": 15.0,
            }


class Lead(BaseModel):
    """Normalized representation of a lead record."""

    name: str
    company: str
    email: str
    last_activity: str
    source: str
    score: float | None = None
    metadata: dict[str, Any] | None = None


class ScoreRequest(BaseModel):
    """Payload accepted by the scoring endpoint."""

    leads: list[Lead] | None = None
    use_ai_boost: bool | None = None


def load_leads_from_file(path: Path = DEFAULT_DATA_PATH) -> list[Lead]:
    """Load and validate leads from a JSON payload."""

    payload = json.loads(path.read_text())
    raw_leads = payload.get("leads", [])
    return [Lead.model_validate(lead) for lead in raw_leads]


def generate_scores(
    leads: Sequence[Lead | dict[str, Any]],
    *,
    weights: RuleWeights | None = None,
    use_ai_boost: bool | None = None,
) -> list[dict[str, Any]]:
    """Apply scoring to a collection of leads."""

    weights = weights or RuleWeights()
    should_use_ai = _resolve_ai_flag(use_ai_boost)

    validated: list[Lead] = [
        lead if isinstance(lead, Lead) else Lead.model_validate(lead) for lead in leads
    ]

    results: list[dict[str, Any]] = []
    for lead in validated:
        score = _rule_based_score(lead, weights)
        if should_use_ai:
            score = _ai_boosted_score(lead, score, weights.max_score)
        record = lead.model_dump()
        record["score"] = round(score, 2)
        results.append(record)
    return results


# ---------------------------------------------------------------------------
# Scoring helpers
# ---------------------------------------------------------------------------


def _rule_based_score(lead: Lead, weights: RuleWeights) -> float:
    score = weights.base

    score += weights.source_weights.get(lead.source.lower(), 10.0)
    score += _recency_bonus(lead.last_activity)

    metadata = lead.metadata or {}
    score += min(float(metadata.get("email_opens", 0)) * 2.2, 15.0)
    score += min(float(metadata.get("call_connects", 0)) * 3.5, 14.0)

    if metadata.get("demo_booked"):
        score += weights.demo_bonus

    if metadata.get("deal_stage", "").lower() in {"proposal", "negotiation"}:
        score += weights.hot_stage_bonus

    if metadata.get("account_tier") == "enterprise":
        score += weights.enterprise_bonus

    if metadata.get("churn_risk"):
        score -= weights.churn_penalty

    score = max(0.0, min(weights.max_score, score))
    return score


def _recency_bonus(last_activity: str) -> float:
    try:
        activity_date = date.fromisoformat(last_activity)
    except ValueError:
        return 0.0

    days_since = (date.today() - activity_date).days
    if days_since < 0:
        return 0.0
    decay = max(0.0, 28.0 - (days_since * 1.4))
    return decay


# ---------------------------------------------------------------------------
# Optional AI booster
# ---------------------------------------------------------------------------


def _resolve_ai_flag(request_flag: bool | None) -> bool:
    if request_flag is not None:
        return request_flag
    env_value = os.getenv("HELIX_AI_BOOST", "0").strip().lower()
    return env_value in {"1", "true", "yes", "on"}


def _ai_boosted_score(lead: Lead, base_score: float, max_score: float) -> float:
    try:
        from openai import OpenAI  # type: ignore[import-not-found]
    except Exception:  # pragma: no cover - optional dependency
        return base_score

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return base_score

    client = OpenAI()
    model = os.getenv("HELIX_AI_MODEL", "gpt-4.1-mini")

    prompt = (
        "You are a sales lead scoring assistant. Given the lead JSON, "
        "respond with a single number between 0 and 100 representing the probability "
        "that the lead will convert this quarter. JSON:"
        f"\n{lead.model_dump_json()}"
    )

    try:
        response = client.responses.create(
            model=model,
            input=prompt,
        )
    except Exception:
        return base_score

    content = getattr(response, "output_text", None)
    if not content:
        # fallback for structured outputs
        content = " ".join(
            chunk.content[0].text
            for chunk in getattr(response, "output", [])
            if getattr(chunk, "content", None)
        )

    if not content:
        return base_score

    match = re.search(r"(-?\d+(?:\.\d+)?)", content)
    if not match:
        return base_score

    suggested = float(match.group(1))
    blended = (base_score * 0.7) + (suggested * 0.3)
    return max(0.0, min(max_score, blended))


# ---------------------------------------------------------------------------
# Utility exposed for scripts
# ---------------------------------------------------------------------------


def top_leads(
    leads: Iterable[Lead | dict[str, Any]],
    *,
    limit: int = 5,
    use_ai_boost: bool | None = None,
) -> list[dict[str, Any]]:
    """Return the highest-scoring leads."""

    scored = generate_scores(list(leads), use_ai_boost=use_ai_boost)
    sorted_leads = sorted(scored, key=lambda item: item.get("score", 0), reverse=True)
    return sorted_leads[:limit]


__all__ = [
    "Lead",
    "ScoreRequest",
    "RuleWeights",
    "generate_scores",
    "load_leads_from_file",
    "top_leads",
]
