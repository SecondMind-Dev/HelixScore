"""Simple APScheduler integration for HelixScore."""

from __future__ import annotations

import asyncio
import logging
import os
import threading

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger

from .connectors.aggregator import fetch_live_leads
from .scoring import top_leads
from .utils.webhook import post_to_slack, post_to_teams

logger = logging.getLogger("helixscore.scheduler")
_scheduler: AsyncIOScheduler | None = None
_loop_thread: threading.Thread | None = None
_loop: asyncio.AbstractEventLoop | None = None


async def _run_cycle() -> None:
    leads = fetch_live_leads()
    winners = top_leads(leads, use_ai_boost=_env_truthy("HELIX_AI_BOOST"))

    slack_url = os.getenv("SLACK_WEBHOOK_URL")
    teams_url = os.getenv("TEAMS_WEBHOOK_URL")

    if not slack_url and not teams_url:
        logger.debug("No webhook URLs configured; skipping broadcast cycle")
        return

    logger.info("HelixScore scheduler broadcasting %d leads", len(winners))
    if slack_url:
        post_to_slack(slack_url, winners)
    if teams_url:
        post_to_teams(teams_url, winners)


def start_scheduler() -> None:
    global _scheduler, _loop_thread, _loop
    if _scheduler and _scheduler.running:
        return

    loop = _ensure_event_loop()
    interval_minutes = int(os.getenv("HELIX_SCHEDULER_INTERVAL_MINUTES", "360"))
    _scheduler = AsyncIOScheduler(event_loop=loop, timezone="UTC")
    _scheduler.add_job(
        lambda: asyncio.run_coroutine_threadsafe(_run_cycle(), loop),
        trigger=IntervalTrigger(minutes=interval_minutes),
        name="helixscore-broadcast",
        next_run_time=None,
    )
    _scheduler.start()
    logger.info("HelixScore scheduler started (interval=%s minutes)", interval_minutes)


def stop_scheduler() -> None:
    global _scheduler, _loop_thread, _loop
    if _scheduler and _scheduler.running:
        _scheduler.shutdown(wait=False)
        logger.info("HelixScore scheduler stopped")
    _scheduler = None

    if _loop and _loop.is_running():
        _loop.call_soon_threadsafe(_loop.stop)

    if _loop_thread and _loop_thread.is_alive():
        _loop_thread.join(timeout=2)

    _loop = None
    _loop_thread = None


def _ensure_event_loop() -> asyncio.AbstractEventLoop:
    global _loop_thread, _loop
    try:
        loop = asyncio.get_running_loop()
        _loop = loop
        return loop
    except RuntimeError:
        pass

    if _loop and _loop.is_running():
        return _loop

    loop = asyncio.new_event_loop()
    _loop = loop

    def runner() -> None:
        asyncio.set_event_loop(loop)
        loop.run_forever()

    _loop_thread = threading.Thread(
        target=runner, name="helixscore-scheduler-loop", daemon=True
    )
    _loop_thread.start()
    return loop


def _env_truthy(key: str, default: str = "0") -> bool:
    value = os.getenv(key, default).strip().lower()
    return value in {"1", "true", "yes", "on"}


__all__ = ["start_scheduler", "stop_scheduler"]
